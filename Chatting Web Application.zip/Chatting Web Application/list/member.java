package list;
/*
Author: Harshit Sharma & Akash Singh
*/

import javax.swing.JFrame;
import javax.swing.*;
import java.lang.*;
import java.util.*;
import java.awt.Color;
import java.awt.Font;
import javax.swing.Box;
import java.awt.Image;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.border.Border;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.net.*;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
 
public class member extends JFrame implements ActionListener{
 
	JTextArea txt = new JTextArea();
    JPanel p1;
	JScrollPane scrolltxt = new JScrollPane(txt);
    JButton b1;
    
	public member() {
 
		p1 = new JPanel();
        p1.setLayout(null);
        p1.setBackground(new Color(7, 94, 84));
        p1.setBounds(0, 0, 400, 70);
        add(p1);
        b1 = new JButton(" Close ");
        b1.setBounds(270,10,122, 50);
        b1.setBackground(Color.BLACK);
        b1.setForeground(Color.WHITE);
        b1.setFont(new Font("SAN_SERIF", Font.PLAIN, 25));
        b1.addActionListener(this);
        p1.add(b1);
        JLabel l1 = new JLabel("***Online User List***");
        l1.setFont(new Font("SAN_SERIF", Font.BOLD, 24));
        l1.setForeground(Color.BLACK);
        l1.setBounds(15, 15, 400, 50);
        p1.add(l1);  
        //txt.setEditable(false);
        txt.setLineWrap(true);
        txt.setWrapStyleWord(true);
        txt.setBackground(new Color(51,255,255));
        txt.setFont(new Font("SAN_SERIF", Font.BOLD, 24));
        scrolltxt.setBounds(0, 70, 400, 400);
		add(scrolltxt);	
        setSize(417, 500);
        setLocation(200, 50);
        setTitle("User's List");
        setLayout(null);
        setVisible(true);
	}
            
    
    public void actionPerformed(ActionEvent ae){
        if(ae.getSource()==b1)
        {
            setVisible(false);     
        }  
    }
    
	/*public static void main(String[] args){
    
		member obj = new member();
        obj.setSize(400, 500);
        obj.setLocation(200, 50);
		obj.setTitle("User's List");
		obj.show();		
	}*/
}