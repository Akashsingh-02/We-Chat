package Login;
/*
Author: Harshit Sharma & Akash Singh
*/

import my.Demo;
import java.lang.*;
import java.util.*;
import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.*;
import javax.swing.border.Border;
public class a implements ActionListener{
    
    Connection con=null;
    PreparedStatement stmt=null;
    public static String serverAddress;
    public static String Username,password;
    public static int port;
    JFrame f1;
    JPanel p1;
    JTextField t1,t3,t4;
    JPasswordField t2;
    JButton btn1,btn2;
    public a(){
      //GUI begins here***** 
       f1 = new JFrame();
        p1 = new JPanel();
        p1.setLayout(null);
        p1.setBackground(new Color(51,255,255));
        p1.setBounds(400,200, 450, 100);
        
        ImageIcon I1 = new ImageIcon(ClassLoader.getSystemResource("myarrow.png"));
        Image I2 = I1.getImage().getScaledInstance(53,53, Image.SCALE_DEFAULT);
        ImageIcon I3 = new ImageIcon(I2);
        JLabel k1 = new JLabel(I3);
        k1.setBounds(6,14, 47, 48);
        k1.setForeground(Color.RED);
        k1.setBackground(Color.BLACK);
        p1.add(k1);
        
        k1.addMouseListener (new MouseAdapter(){
        public void mouseClicked(MouseEvent ae) {
        System.exit(0);}
        });
        
        
        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("chat_icon.png"));
        Image i2 = i1.getImage().getScaledInstance(110,110, Image.SCALE_DEFAULT);
        ImageIcon i3 = new ImageIcon(i2);
        JLabel l1 = new JLabel(i3);
        l1.setBounds(165, 35, 110,200);
        l1.setForeground(Color.RED);
        l1.setBackground(Color.BLACK);
        p1.add(l1);
        
        
        JLabel l3 = new JLabel("Log In");
        l3.setFont(new Font("SAN_SERIF", Font.PLAIN, 40));
        l3.setForeground(Color.BLACK);
        l3.setBounds(170, 35, 200,370);
        p1.add(l3);
        
        ImageIcon i4 = new ImageIcon(ClassLoader.getSystemResource("usericon.png"));
        Image i5 = i4.getImage().getScaledInstance(40,40, Image.SCALE_DEFAULT);
        ImageIcon i6 = new ImageIcon(i5);
        JLabel l4 = new JLabel(i6);
        l4.setBounds(25, 180, 110,200);
        l4.setForeground(Color.RED);
        l4.setBackground(Color.BLACK);
        p1.add(l4);
        
        
        t1 = new JTextField(" Username ");
        t1.setBounds(110, 260, 250,35);
        t1.setBackground(Color.lightGray);
        Border b1 = BorderFactory.createLineBorder(Color.lightGray,1);
        t1.setBorder(b1);
        t1.setFont(new Font("SAN_SERIF", Font.BOLD, 18));
        p1.add(t1);
      
        
        t1.addMouseListener (new MouseAdapter(){
        public void mouseClicked(MouseEvent ae) {
        t1.setText("");}
        });
        
        
        ImageIcon i7 = new ImageIcon(ClassLoader.getSystemResource("passwordicon.png"));
        Image i8 = i7.getImage().getScaledInstance(40,40, Image.SCALE_DEFAULT);
        ImageIcon i9 = new ImageIcon(i8);
        JLabel l5 = new JLabel(i9);
        l5.setBounds(25, 232, 110,200);
        l5.setForeground(Color.RED);
        l5.setBackground(Color.BLACK);
        p1.add(l5);
        
        
        t2 = new JPasswordField(" Password ");
        t2.setBounds(110, 315, 250,35);
        Border b2 = BorderFactory.createLineBorder(Color.lightGray,1);
        t2.setBackground(Color.lightGray);
        t2.setFont(new Font("SAN_SERIF", Font.BOLD, 18));
        t2.setBorder(b2);
        p1.add(t2);
        
        t2.addMouseListener (new MouseAdapter(){
        public void mouseClicked(MouseEvent ae) {
        t2.setText("");}
        });
        
        ImageIcon i10 = new ImageIcon(ClassLoader.getSystemResource("ip.png"));
        Image i11 = i10.getImage().getScaledInstance(40,40, Image.SCALE_DEFAULT);
        ImageIcon i12 = new ImageIcon(i11);
        JLabel l6 = new JLabel(i12);
        l6.setBounds(25, 288, 110,200);
        l6.setForeground(Color.RED);
        l6.setBackground(Color.BLACK);
        p1.add(l6);
        
        
        
        t3 = new JTextField(" Server Address ");
        t3.setBounds(110, 370, 250,35);
        t3.setBackground(Color.lightGray);
        Border b3 = BorderFactory.createLineBorder(Color.lightGray,1);
        t3.setBorder(b1);
        t3.setFont(new Font("SAN_SERIF", Font.BOLD, 18));
        p1.add(t3);
        
        t3.addMouseListener (new MouseAdapter(){
        public void mouseClicked(MouseEvent ae) {
        t3.setText("");}
        });
        
        ImageIcon i13 = new ImageIcon(ClassLoader.getSystemResource("portno.png"));
        Image i14 = i13.getImage().getScaledInstance(40,40, Image.SCALE_DEFAULT);
        ImageIcon i15 = new ImageIcon(i14);
        JLabel l7 = new JLabel(i15);
        l7.setBounds(25, 342, 110,200);
        l7.setForeground(Color.RED);
        l7.setBackground(Color.BLACK);
        p1.add(l7);
        
        t4 = new JTextField(" Port No  ");
        t4.setBounds(110, 425,250,35);
        t4.setBackground(Color.lightGray);
        Border b4 = BorderFactory.createLineBorder(Color.lightGray,1);
        t4.setBorder(b1);
        t4.setFont(new Font("SAN_SERIF", Font.BOLD, 18));
        p1.add(t4);
        
        t4.addMouseListener (new MouseAdapter(){
        public void mouseClicked(MouseEvent ae) {
        t4.setText("");}
        });
        
        btn1 =new JButton("Log In");  
        btn1.setFont(new Font("SAN_SERIF", Font.PLAIN, 20));
        btn1.setForeground(Color.BLACK);
        btn1.setBounds(160, 475,150,40);
        btn1.addActionListener(this);
        p1.add(btn1);    
        
                
        //f1.getContentPane().setBackground(Color.GRAY);
        f1.add(p1);
        f1.setSize(450,670);
        f1.setLocation(470,10);
        f1.setUndecorated(true);
        f1.setVisible(true);
        }

    public void actionPerformed(ActionEvent e){
	// TODO Auto-generated method stub
        if(e.getSource()==btn1)
        {
            try {
         // establihing Connection with MySql Database**** 
              
                Class.forName("com.mysql.cj.jdbc.Driver");
                con = DriverManager.getConnection("jdbc:mysql://myharshitdata.cpnnjboqzqhz.ap-south-1.rds.amazonaws.com:3306/signup_details","admin","HarshitSharma");
                String sql = "Select * from mysignupform where username=? and userpassword=?";
                stmt = con.prepareStatement(sql);
                stmt.setString(1,t1.getText());
                stmt.setString(2,t2.getText());
                this.serverAddress = t3.getText();
                this.port = Integer.parseInt(t4.getText());
                this.Username = t1.getText();
                
                ResultSet rs = stmt.executeQuery();
              
                 //pop-up box after matching the details from database  
                if(rs.next()){
                JOptionPane.showMessageDialog(null, "Login Succesfully","Congratulation",JOptionPane.INFORMATION_MESSAGE);
                f1.setVisible(false);
                Demo one = new Demo(serverAddress,port,Username);
                Thread t1 = new Thread(one);
                t1.start();
                }
                else
                {
                    JOptionPane.showMessageDialog(null, "Username and Password Donot Match","Try Again",JOptionPane.INFORMATION_MESSAGE);
                    t1.setText(" Username ");
                    t2.setText(" Password ");
                    t3.setText(" Server Address ");
                    t4.setText(" Port No ");
                }
                con.close();    
            }
            
            catch(SQLException ev){
                System.out.println("Sql Exception Found");
            }
            catch(ClassNotFoundException eq){
                System.out.println("Sql Exception Found 2");
                System.out.println(eq);
            }
        }
    } 
    
    
    
    /*public static void main(String[] args){
        new a();
    }  */  

    void setVisible(boolean b) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}