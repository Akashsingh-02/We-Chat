package Data;
/*
Author: Harshit Sharma & Akash Singh
*/

import list.member;
import java.lang.*;
import java.util.*;
import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.*;
import javax.swing.border.Border;
import java.sql.*;

public class datafetch extends JFrame implements ActionListener{
    Connection con=null;
    PreparedStatement stmt=null;
    JPanel p1;
    public static String Username;
    JButton b0,b1,b2;
    static JLabel l0,l1,l2,l3,l4,l5,l6,l7,l8,l9,l10,l11,l12,t1,t2,t3,t4,t5,t6;;
    JTextField t0;
    static JTextArea a1;
    JScrollPane s1;
  
    public static Connection letConnect(){
//Connecting with MySql database****
        Connection con = null;
        String url, username,password;
        url="jdbc:mysql://myharshitdata.cpnnjboqzqhz.ap-south-1.rds.amazonaws.com:3306/signup_details";
        username = "admin";
        password = "HarshitSharma";
        try{
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection(url,username,password);
            System.out.println("Connected");
        }catch(SQLException | ClassNotFoundException e)
        {
            e.printStackTrace();
        }
        return con;
    }
  
// GUI part of code for showing user details******
    public datafetch(String Username){
        this.Username = Username;
        p1 = new JPanel();
        p1.setLayout(null);
        p1.setBackground(new Color(7, 94, 84));
        p1.setBounds(0, 0, 425, 100);
        add(p1);
        getContentPane().setBackground(Color.BLACK);
        
        b0 = new JButton(" Online User's ");
        b0.setBounds(5,25,200, 50);
        b0.setBackground(Color.BLACK);
        b0.setForeground(Color.WHITE);
        b0.setFont(new Font("SAN_SERIF", Font.PLAIN, 25));
        b0.addActionListener(this);
        p1.add(b0);

        b1 = new JButton(" Close ");
        b1.setBounds(290,25,122, 50);
        b1.setBackground(Color.BLACK);
        b1.setForeground(Color.WHITE);
        b1.setFont(new Font("SAN_SERIF", Font.PLAIN, 25));
        b1.addActionListener(this);
        p1.add(b1);
        
        l0 = new JLabel("!***User Profile***!");
        l0.setBounds(15, 25, 770,50);
        l0.setForeground(Color.GREEN);
        l0.setFont(new Font("SAN_SERIF", Font.BOLD,30));
        add(l0); 
        
        
        l1 = new JLabel("Full Name: ");
        l1.setBounds(5, 80, 150,200);
        l1.setForeground(Color.ORANGE);
        l1.setFont(new Font("SAN_SERIF", Font.BOLD,20));
        add(l1);    
       
        t1 = new JLabel("************************");
        t1.setBounds(150, 165, 225,30);
        //t1.setBackground(Color.WHITE);
        t1.setForeground(Color.ORANGE);
        t1.setFont(new Font("SAN_SERIF", Font.PLAIN, 22));
        add(t1); 
       
        l2 = new JLabel("User Name: ");
        l2.setBounds(5, 120, 200,200);
        l2.setForeground(Color.ORANGE);
        l2.setFont(new Font("SAN_SERIF", Font.BOLD,20));
        add(l2);
        
        t2 = new JLabel("************************");
        t2.setBounds(150, 205, 225,30);
        //t2.setBackground(Color.WHITE);
        t2.setForeground(Color.ORANGE);
        t2.setFont(new Font("SAN_SERIF", Font.PLAIN, 22));
        add(t2); 
       
       
        
        
        l3 = new JLabel("Password: ");
        l3.setBounds(5, 160, 200,200);
        l3.setForeground(Color.ORANGE);
        l3.setFont(new Font("SAN_SERIF", Font.BOLD,20));
        add(l3);
        
        t3 = new JLabel("************************");
        t3.setBounds(150, 245,225,30);
        //t3.setBackground(Color.WHITE);
        t3.setForeground(Color.ORANGE);
        t3.setFont(new Font("SAN_SERIF", Font.PLAIN, 22));
        add(t3); 
        
        l4 = new JLabel("Email: ");
        l4.setBounds(5, 200, 200,200);
        l4.setForeground(Color.ORANGE);
        l4.setFont(new Font("SAN_SERIF", Font.BOLD,20));
        add(l4);
        
        t4 = new JLabel("************************");
        t4.setBounds(150, 282, 225,30);
        //t4.setBackground(Color.WHITE);
        t4.setForeground(Color.ORANGE);
        t4.setFont(new Font("SAN_SERIF", Font.PLAIN, 22));
        add(t4); 
        
        
        l5 = new JLabel("Phone No: ");
        l5.setBounds(5, 240,200,200);
        l5.setForeground(Color.ORANGE);
        l5.setFont(new Font("SAN_SERIF", Font.BOLD,20));
        add(l5);
        
        t5 = new JLabel("************************");
        t5.setBounds(150, 322, 225,30);
        //t5.setBackground(Color.WHITE);
        t5.setForeground(Color.ORANGE);
        t5.setFont(new Font("SAN_SERIF", Font.PLAIN, 22));
        add(t5); 
        
        l6 = new JLabel("Gender: ");
        l6.setBounds(5, 280, 200,200);
        l6.setForeground(Color.ORANGE);
        l6.setFont(new Font("SAN_SERIF", Font.BOLD,20));
        add(l6);
       
        t6 = new JLabel("************************");
        t6.setBounds(150, 368, 225,30);
        //t6.setBackground(Color.WHITE);
        t6.setForeground(Color.ORANGE);
        t6.setFont(new Font("SAN_SERIF", Font.PLAIN, 22));
        add(t6); 
        
        b2 = new JButton(" Check Profile ");
        b2.setBounds(170,420,235, 50);
        b2.setBackground(Color.BLACK);
        b2.setForeground(Color.RED);
        Border bor1 = BorderFactory.createLineBorder(Color.BLUE,1);
        b2.setBorder(bor1);
        b2.setFont(new Font("SAN_SERIF", Font.PLAIN, 30));
        b2.addActionListener(this);
        add(b2);
        
        
        setLayout(null);
        setSize(444, 700);
        setLocation(460, 10); 
        //setUndecorated(true);
        setVisible(true);   
    
    }
    
    // fetching details from MySql to display in Profiile Details******
    public void actionPerformed(ActionEvent ae){
        if(ae.getSource()==b0)
        {
            member p = new member();     
        }  
        if(ae.getSource()==b1)
        {
            setVisible(false);     
        }  
        if(ae.getSource()==b2)
        {
            datafetch.letConnect();
            Connection con = letConnect();
            String sql = "select * from mysignupform";
            try{
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery(sql);
            while(rs.next()){
                if(rs.getString(2).equals(Username)){
                t1.setText(rs.getString(1));
                t2.setText(rs.getString(2));
                t3.setText("**********");
                t4.setText(rs.getString(4));
                t5.setText(rs.getString(5));
                t6.setText(rs.getString(6));
                //System.out.println(rs.getString(1)+ " " + rs.getString(2)+" "+rs.getString(3)+ " " + rs.getString(4)+" "+rs.getString(5)+ " " + rs.getString(6));
                }
                }
            }
            catch(SQLException e)
            {
                e.printStackTrace();
            }
        }
        
    }
    
    
    
    /*public static void main(String[] args){
        datafetch d = new datafetch();
        //datafetch.FetchData();
    }*/
}