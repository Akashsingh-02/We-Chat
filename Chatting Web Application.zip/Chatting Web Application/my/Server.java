//package group_chatting;
/*
Author: Harshit Sharma & Akash Singh
*/
import java.io.*;
import java.net.*;
import java.util.Vector;

public class Server implements Runnable{

   Socket socket;
   
   public static Vector client = new Vector();

    public Server(Socket socket){//constructor for socket******
         try{
             this.socket = socket;
            }
        catch(Exception e){}
    }
    
    public void run(){
        try{
            BufferedReader reader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));
            
            client.add(writer);
            
            while(true){//infinite loop for messages*****
                String data = reader.readLine().trim();
                System.out.println(data);
                for(int i=0;i<client.size();i++){//for writing the data in vector****
                   try{
                       BufferedWriter bw = (BufferedWriter) client.get(i);
                       bw.write(data);
                       bw.write("\r\n");
                       bw.flush();
                   }catch(Exception e) {}
                
                }
                }
        }
        catch(Exception e){}
    }
    
    public static void main(String[] args) throws IOException{//reading socket and connecting them****
        
        ServerSocket s = new ServerSocket(2005);
        System.out.println("Server Started: ");
        while(true){//connecting all client******
    
            Socket socket = s.accept();
            Server server = new Server(socket);
            Thread thread = new Thread(server);
            thread.start();
        }   
    }
}