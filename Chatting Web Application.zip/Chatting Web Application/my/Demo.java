package my;

/*
 @author Harshit Sharma & Akash Singh
 */

import Data.datafetch;
import javax.swing.*;
import javax.swing.Timer;
import javax.swing.*;
import java.lang.*;
import java.util.*;
import java.awt.Color;
import java.awt.Font;
import javax.swing.Box;
import java.awt.Image;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.awt.event.ActionListener;
import javax.swing.text.BadLocationException;
import javax.swing.text.SimpleAttributeSet;
import javax.swing.text.Style;
import javax.swing.text.StyleConstants;
import javax.swing.text.StyledDocument;
import javax.swing.text.Document;
import javax.swing.*;
import javax.swing.border.*;
import java.io.*;
import javax.swing.filechooser.*;
import java.awt.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.border.Border;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.net.*;
import javax.swing.Timer;
import java.lang.*;
import java.util.*;
import java.awt.Color;
import java.awt.Font;
import java.sql.SQLException;
import java.awt.event.ActionListener;
import javax.swing.text.BadLocationException;
import javax.swing.text.SimpleAttributeSet;
import javax.swing.text.Style;
import javax.swing.text.StyleConstants;
import javax.swing.text.StyledDocument;
import javax.swing.text.Document;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.border.Border;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.net.*;

public class Demo extends JFrame implements ActionListener, Runnable{
    JPanel p1,p2;
    public static String serverAddress;
    public static String Username;
    public static String Fullname;
    public static int port;
    JTextField t1;
    JButton b1,b2,b3,b4;
    static JTextArea a1;
    JScrollPane s1;
    JPanel is3 = new JPanel();
    JTextPane textPane = new JTextPane();
    JFileChooser fileC = new JFileChooser();
    BufferedWriter writer;
    BufferedReader reader;
    boolean typing = false;

    public Demo(String serverAddress,int port,String Username){
        // Calling the constructor part for establishing connection ******
        this.serverAddress =serverAddress;
        this.port = port;
        this.Username = Username;
        p1 = new JPanel();
        p1.setLayout(null);
        p1.setBackground(new Color(7, 94, 84));
        p1.setBounds(0, 0, 425, 100);
        add(p1);
        textPane.setEditable(false);
        is3.setBounds(0,0,120,100);
		is3.setBackground(Color.WHITE);
		textPane.setPreferredSize(new Dimension(120,100));

        
//  GUI part of the Client part********       
        ImageIcon i4 = new ImageIcon(ClassLoader.getSystemResource("usericon.png"));
        Image i5 = i4.getImage().getScaledInstance(60, 60, Image.SCALE_DEFAULT);
        ImageIcon i6 = new ImageIcon(i5);
        JLabel l2 = new JLabel(i6);
        l2.setBounds(1, 1,120, 100);
        p1.add(l2);
        
        b2 = new JButton(" Profile ");
        b2.setBounds(290,7,122, 40);
        b2.setBackground(Color.BLACK);
        b2.setForeground(Color.WHITE);
        b2.setFont(new Font("SAN_SERIF", Font.PLAIN, 25));
        b2.addActionListener(this);
        p1.add(b2);
       
        b4 = new JButton(" Photo ");
        b4.setBounds(290,55,122, 40);
        b4.setBackground(Color.BLACK);
        b4.setForeground(Color.WHITE);
        b4.setFont(new Font("SAN_SERIF", Font.PLAIN, 25));
        b4.addActionListener(this);
        p1.add(b4);
       
        JLabel l3 = new JLabel(Username);
        l3.setFont(new Font("SAN_SERIF", Font.BOLD, 24));
        l3.setForeground(Color.RED);
        l3.setBounds(130, 15, 165, 18);
        p1.add(l3);   
       
        Fullname = l3.getText();
       
        JLabel l4 = new JLabel("Active Now");
        l4.setFont(new Font("SAN_SERIF", Font.PLAIN, 22));
        l4.setForeground(Color.RED);
        l4.setBounds(130, 45, 160, 30);
        p1.add(l4);   
       
        Timer t = new Timer(1, new ActionListener(){
           public void actionPerformed(ActionEvent ae){
               if(!typing){
                   l4.setText("Active Now");
               }
           }
        });
       
        t.setInitialDelay(1000);
         
       
        a1 = new JTextArea();
        s1 = new JScrollPane(a1);  
        s1.setBounds(1, 101, 424, 507);
        a1.setBackground(new Color(51,255,255));
        a1.setFont(new Font("SAN_SERIF", Font.BOLD, 22));
        a1.setEditable(false);
        a1.setLineWrap(true);
        a1.setWrapStyleWord(true);
        add(s1);
        
        
       
        t1 = new JTextField(" Type a message ");
        t1.setBounds(70, 610, 250, 40);
        t1.addActionListener(this);
        t1.setFont(new Font("SAN_SERIF", Font.PLAIN, 22));
        add(t1);
        
        t1.addMouseListener (new MouseAdapter(){
        public void mouseClicked(MouseEvent ae) {
        t1.setText("");}
        });
        
        t1.addKeyListener(new KeyAdapter(){
           public void keyPressed(KeyEvent ke){
                l4.setText("typing...");     
                t.stop();
                typing = true;
           }
           
           public void keyReleased(KeyEvent ke){
               typing = false;
               
               if(!t.isRunning()){
                   t.start();
               }
           }
        });
        
        b1 = new JButton("Send");
        b1.setBounds(330, 610, 95, 40);
        b1.setBackground(new Color(7, 94, 84));
        b1.setForeground(Color.WHITE);
        b1.setFont(new Font("SAN_SERIF", Font.PLAIN, 16));
        b1.addActionListener(this);
        add(b1);
        
        
        ImageIcon icon = new ImageIcon(ClassLoader.getSystemResource("happy.gif"));
        b3 = new JButton(icon);
        b3.setBounds(2, 610,60, 40);
        b3.setForeground(Color.WHITE);
        b3.addActionListener(this);
        add(b3);

	b3.addMouseListener (new MouseAdapter(){
        		public void mouseClicked(MouseEvent ae) {
        			try{
                			String hpy = Username+":  SMILE"; 
                			writer.write(hpy);
                			writer.write("\r\n");
                			writer.flush();
            			}
            catch(Exception evt){System.out.println("Couldn't send emoji quotes");}
		}
        		});
        
        is3.add(textPane);
        add(is3);
        add(b4);
        getContentPane().setBackground(Color.BLACK);
        setLayout(null);
        setSize(444, 700);
        setLocation(10, 10); 
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        //setUndecorated(true);
        setVisible(true);
       
        try{
  // establishing the connection for client*****
           InetAddress ip = InetAddress.getByName(serverAddress);
           Socket socketClient = new Socket(ip, port);
           writer = new BufferedWriter(new OutputStreamWriter(socketClient.getOutputStream()));
           reader = new BufferedReader(new InputStreamReader(socketClient.getInputStream()));
           //Message for User connected*****
	try{
	String join ="          "+ Username+" has just poped in !!!! \n";
	writer.write("\r");
	writer.write(join);
	writer.write("\r\n");
	writer.flush();
	}catch(Exception a){System.out.println("Join Message can't be displayed");}
        }catch(Exception e){}        
    }   
    
    public void actionPerformed(ActionEvent ae){
        if(ae.getSource()==b2)
        {
            datafetch p = new datafetch(Username);
        }
        if(ae.getSource()==b4)//chosser for chossing profile pic****
        {
			fileC.setFileFilter(new FileNameExtensionFilter("Open Image","jpg","jpeg","gif"));
			int returnval = fileC.showOpenDialog(null);
			if(returnval == JFileChooser.APPROVE_OPTION)
			{
				File file = fileC.getSelectedFile();	
				ImageIcon iconpb = new ImageIcon(file.getAbsolutePath());
				Image ipb = iconpb.getImage(); 
				Image new_imgpb = ipb.getScaledInstance(120,100,Image.SCALE_SMOOTH);
				iconpb = new ImageIcon(new_imgpb);
				Document doc = textPane.getDocument();
				int cl = doc.getLength();
				textPane.setSelectionStart(0);
				textPane.setSelectionEnd(cl);
				textPane.insertIcon(iconpb);
			}  
        }
        
// for passing the message to server via send button******
        if(ae.getSource()==b1 || ae.getSource()==t1){
            try{
                String str = Username + ": "+ t1.getText();
                writer.write(str);
                writer.write("\r\n");
                writer.flush();
            }
            catch(Exception e){}
            t1.setText(" Type a message ");
        }
        
    }
    
    public void run(){// passing the message to text area and server
        try{
            String msg = "";
            while((msg = reader.readLine()) != null){
                a1.append(msg + "\n");
            }
        }catch(Exception e){}
 /*finally{
	try{String close ="          "+ Username+" has just left the Conversation !!!! \n";
	writer.write("\r");
	writer.write(close);
	writer.write("\r\n");
	writer.flush();
	}catch(Exception ae){System.out.println("Couldn't pass close statement");}
	}*/
    }
    /*public static void main(String[] args)
    {   
	String serverAddress1 = "localhost";
	int port1 = 2005;
	Scanner sc = new Scanner(System.in);
    System.out.println("Enter the ServerAddress: ");
	serverAddress1 = sc.nextLine();

	System.out.println("Enter the Port no.: ");.

	port1 = sc.nextInt();

	//int port =Integer.parseInt(args[1]);
    Demo one = new Demo(serverAddress1,port1);
    Thread t1 = new Thread(one);
    t1.start();
    }*/
}
