/*
  @author Harshit Sharma and Akash Singh
 */
import Login.a;
import java.lang.ClassNotFoundException;
import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.*;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import javax.swing.*;
import javax.swing.border.Border;
public class MySignUpForm implements ActionListener{
    
    Connection con=null;
    PreparedStatement stmt=null;
    
    
    JFrame f1;
    JPanel p1;
    JComboBox c1;
    JTextField t1,t2,t4,t5;
    JPasswordField t3;
    JButton btn1,btn2;
    
    MySignUpForm(){
        //Establishing connection with Database******   
        try{
            Class.forName("com.mysql.cj.jdbc.Driver");
        }
        catch(ClassNotFoundException eq){
				System.out.println("sql exception found 2");
				System.out.println(eq);
		}   
            
       // GUI of MySignUpForm ******     
        f1 = new JFrame();
        p1 = new JPanel();
        p1.setLayout(null);
        p1.setBackground(new Color(51,255,255));
        p1.setBounds(400,200, 450, 70);
        
        
        
        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("myarrow.png"));
        Image i2 = i1.getImage().getScaledInstance(43,43, Image.SCALE_DEFAULT);
        ImageIcon i3 = new ImageIcon(i2);
        JLabel l1 = new JLabel(i3);
        l1.setBounds(9,14, 40, 48);
        l1.setForeground(Color.RED);
        l1.setBackground(Color.BLACK);
        p1.add(l1);
        
        l1.addMouseListener (new MouseAdapter(){
        public void mouseClicked(MouseEvent ae) {
        System.exit(0);}
        });
        
     
        
        JLabel l3 = new JLabel("Sign Up");
        l3.setFont(new Font("SAN_SERIF", Font.PLAIN, 40));
        l3.setForeground(Color.BLACK);
        l3.setBounds(135, 35, 200,70);
        p1.add(l3);
        
        
        t1 = new JTextField(" Full Name ");
        t1.setBounds(77, 120, 250,35);
        t1.setBackground(Color.lightGray);
        Border b1 = BorderFactory.createLineBorder(Color.lightGray,1);
        t1.setBorder(b1);
        t1.setFont(new Font("SAN_SERIF", Font.BOLD, 18));
        p1.add(t1);
        
        t1.addMouseListener (new MouseAdapter(){
        public void mouseClicked(MouseEvent ae) {
        t1.setText("");}
        });
        
      
        t2 = new JTextField(" Username ");
        t2.setBounds(77, 165, 250,35);
        Border b2 = BorderFactory.createLineBorder(Color.lightGray,1);
        t2.setBackground(Color.lightGray);
        t2.setFont(new Font("SAN_SERIF", Font.BOLD, 18));
        t2.setBorder(b2);
        p1.add(t2);
        
        t2.addMouseListener (new MouseAdapter(){
        public void mouseClicked(MouseEvent ae) {
        t2.setText("");}
        });
        
        t3 = new JPasswordField(" Password ");
        t3.setBounds(77, 210, 250,35);
        Border b3 = BorderFactory.createLineBorder(Color.lightGray,1);
        t3.setBackground(Color.lightGray);
        t3.setFont(new Font("SAN_SERIF", Font.BOLD, 18));
        t3.setBorder(b3);
        p1.add(t3);
        
        t3.addMouseListener (new MouseAdapter(){
        public void mouseClicked(MouseEvent ae) {
        t3.setText("");}
        });
        
        t4 = new JTextField(" Email ");
        t4.setBounds(77, 255, 250,35);
        t4.setBackground(Color.lightGray);
        Border b4 = BorderFactory.createLineBorder(Color.lightGray,1);
        t4.setBorder(b4);
        t4.setFont(new Font("SAN_SERIF", Font.BOLD, 18));
        p1.add(t4);
        
        t4.addMouseListener (new MouseAdapter(){
        public void mouseClicked(MouseEvent ae) {
        t4.setText("");}
        });
  
        t5 = new JTextField(" Phone Number ");
        t5.setBounds(77, 300, 250,35);
        Border b5 = BorderFactory.createLineBorder(Color.lightGray,1);
        t5.setBackground(Color.lightGray);
        t5.setFont(new Font("SAN_SERIF", Font.BOLD, 18));
        t5.setBorder(b5);
        p1.add(t5);
        
        t5.addMouseListener (new MouseAdapter(){
        public void mouseClicked(MouseEvent ae) {
        t5.setText("");}
        });
        
        JLabel l4 = new JLabel("Gender:");
        l4.setFont(new Font("SAN_SERIF", Font.BOLD, 20));
        l4.setForeground(Color.BLACK);
        l4.setBounds(77, 340, 100,40);
        p1.add(l4);
        
        String gen[]={"Select One","Male","Female","Other"};        
        c1=new JComboBox(gen);
        c1.setFont(new Font("SAN_SERIF", Font.PLAIN, 15));
        c1.setBounds(160, 345,100,30);
        p1.add(c1);
        
       
        btn1 =new JButton("Create Account");  
        btn1.setFont(new Font("SAN_SERIF", Font.PLAIN, 20));
        btn1.setForeground(Color.BLACK);
        btn1.setBounds(110,420,190,40);
        btn1.addActionListener(this);
        p1.add(btn1); 
        
            
        JLabel l5 = new JLabel("Already Have an Account?");
        l5.setFont(new Font("SAN_SERIF", Font.PLAIN, 20));
        l5.setForeground(Color.BLACK);
        l5.setBounds(79, 550, 350,40);
        p1.add(l5);
        
        btn2 =new JButton("Log In Here"); 
        btn2.setFont(new Font("SAN_SERIF", Font.PLAIN, 20));
        btn2.setForeground(Color.BLACK);
        btn2.setBounds(120, 595,150,40);
        btn2.addActionListener(this);
        p1.add(btn2);
        
        
        
        f1.add(p1);
        //f1.getContentPane().setBackground(Color.GRAY);
        f1.setSize(400,670);
        f1.setLocation(470,10);
        f1.setUndecorated(true);
        f1.setVisible(true);
    }
    @Override
    public void actionPerformed(ActionEvent e) 
    {
	// TODO Auto-generated method stub
    
        if(e.getSource()==btn1)
        {   
            // Establishing Connection and Appending data into it.****** 
            try{
                Class.forName("com.mysql.cj.jdbc.Driver");
                String url="jdbc:mysql://myharshitdata.cpnnjboqzqhz.ap-south-1.rds.amazonaws.com:3306/signup_details";
                String uname = "admin";
                String password = "HarshitSharma";
                String query = "INSERT into mysignupform values(?,?,?,?,?,?)";
                con = DriverManager.getConnection(url,uname,password);
                stmt = con.prepareStatement(query);
                stmt.setString(1,t1.getText());
                stmt.setString(2,t2.getText());
                stmt.setString(3,t3.getText());
                stmt.setString(4,t4.getText());
                stmt.setString(5,t5.getText());
                stmt.setString(6,c1.getSelectedItem().toString());
                stmt.executeUpdate();
                JOptionPane.showMessageDialog(null, "Account Created Succesfully","Congratulation",JOptionPane.INFORMATION_MESSAGE);
                t1.setText(" Full Name ");
                t2.setText(" Username ");
                t3.setText(" Password ");
                t4.setText(" Email ");
                t5.setText(" Phone No ");
                String s[] = {"Select One"};
                c1 = new JComboBox(s);
            }
            catch(Exception ex){
                  JOptionPane.showMessageDialog(null,ex);
            }
        }
        if(e.getSource()==btn2)
        {
            f1.setVisible(false);
            a first = new a();
        }
    }
    
    public static void main(String[] args){
        new MySignUpForm();
    }    

    void setVisible(boolean b) {
        throw new UnsupportedOperationException("Not supported yet.");
        //To change body of generated methods, choose Tools | Templates.
    }
}
